<?php
/**
 * Asset file for HM Promo Grid editor script.
 */
return array(
	'dependencies' => array(
		'wp-blocks',
		'wp-element',
		'wp-i18n',
		'wp-components',
		'wp-block-editor',
		'wp-editor',
	),
	'version' => '0.1.0',
);
